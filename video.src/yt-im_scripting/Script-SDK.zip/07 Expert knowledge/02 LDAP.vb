'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'********************************************************************
'*
'* This sample shows LDAP searches using the ADSI OLEDB provider from
'* C:\Program Files\Microsoft.NET\Primary Interop Assemblies\adodb.dll.
'* 
'* Additionally there are some query samples and syntax description.
'*
'********************************************************************

' Reference the external DLL
#If Not SCRIPTDEBUGGER Then
References C:\Programme\Microsoft.NET\Primary Interop Assemblies\adodb.dll
#End If

Public Sub Expert_LDAP()

	Dim ldapConnection As ADODB.Connection = New ADODB.ConnectionClass
	Dim ldapCommand As ADODB.Command = New ADODB.CommandClass
	Dim ldapResult As ADODB.Recordset
	Dim i As Integer
	Dim strResult As String
	Dim strQuery As String

	Try

		ldapConnection.Provider = "ADsDSOObject"		   'this is the ADSI-OLEDB provider name
		ldapConnection.Properties("User ID").Value = "cn=administrator,cn=useldapResult,DC=domain"
		ldapConnection.Properties("Password").Value = "password"
		ldapConnection.Properties("Encrypt Password").Value = True
		ldapConnection.Open("DS Query")

		ldapCommand.ActiveConnection = ldapConnection

		'*********************************************
        '*  Query (Samples)
		'*********************************************
        ' All objects of an object class (Computer)
		strQuery = "select Adspath from 'LDAP://DH04-S01/DC=domain' where object Class = 'COMPUTER'"

        ' All users owning an Exchange mailbox (Sample for existence check for a property)
		'strQuery = "select Adspath from 'LDAP://DH04-S01/DC=domain' where objectClass = 'USER' AND MailNickName = '*'"

        ' All users with a surname starting with 'Z'
		'strQuery = "select Adspath from 'LDAP://DH04-S01/DC=domain' where objectClass = 'USER' AND sn = 'Z*'"

        ' All users with a surname NOT starting with 'Z'
		'strQuery = "select Adspath from 'LDAP://DH04-S01/DC=domain' where objectClass = 'USER' AND NOT sn = 'Z*'"

		ldapCommand.CommandText = strQuery

		ldapResult = ldapCommand.Execute

		If Not ldapResult.EOF Then
			ldapResult.MoveFirst()
			System.Diagnostics.Debug.WriteLine(CStr(ldapResult.RecordCount) & " rows affected.")
		End If

		Do
			strResult = CStr(ldapResult.Fields.Item("Adspath").Value)

			System.Diagnostics.Debug.WriteLine(strResult)

			ldapResult.MoveNext()

		Loop While Not ldapResult.EOF

	Catch ex As Exception

        ' Handle errors

		Throw
	Finally
		If Not ldapResult Is Nothing Then ldapResult.Close()
		If Not ldapConnection Is Nothing Then ldapConnection.Close()
	End Try

End Sub


'********************************************************************
'*
'* Der ADSI-OLEDB Provider unterst�tzt folgende Syntax
'*
'********************************************************************


'SQL statements require the following syntax.

SELECT [ALL] * | select-list FROM 'ADsPath' [WHERE search-condition] [ORDER BY sort-list]
SELECT ADsPath, cn FROM 'LDAP://DC=Fabrikam,DC=COM' WHERE objectCategory='group'


'To search for all the users whose Last Name starts with letter H.


SELECT ADsPath, cn FROM 'LDAP://OU=Sales,DC=Fabrikam,DC=COM' WHERE objectCategory='person' AND objectClass='user' AND sn = 'H*' ORDER BY sn

' The formal grammar for SQL queries is defined in the following code example. All keywords are case-insensitive.

statement ::= select-statement
select-statement ::= SELECT [ALL] select-list FROM table-identifier [WHERE search-condition] [ORDER BY sort-list]
select-list ::= * | select-sublist [, select-sublist]... 
select-sublist ::= column-identifier
column-identifier ::= user-defined-name 
table-identifier ::= string-literal
search-condition ::= boolean-term [OR search-condition]
sort-list ::= column-identifier [ASC | DESC] [,column-identifier [ASC | DESC]]... 
boolean-term ::= boolean-factor [AND boolean-term]
boolean-factor ::= [NOT] boolean-primary
boolean-primary ::= comparison-predicate | (search-condition)
comparison-predicate ::= column-identifier comparison-[operator] literal
comparison-[operator] ::= < | > | <= | >= | = | <>
user-defined-name ::= letter [letter | digit]...
literal ::= string-literal | numeric-literal | boolean-literal 
string-literal ::= '{character}...' (Any sequence of characters delimited by quotes)
numeric-literal ::= digits [fraction] [exponent]
digits ::= digit [digit]...
fraction ::= . digits 
exponent ::= E digits
boolean-literal ::= TRUE | FALSE | YES | NO | ON | OFF
