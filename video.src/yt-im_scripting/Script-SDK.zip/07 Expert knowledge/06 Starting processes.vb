'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* This sample demonstrates the execution of command line commands.
'* Execution is done synchronously. Standard output and standard error
'* streams and the return code are read.
'*
'*************************************************************************

Public Sub Task_Execute_Windows(ByVal strCMDLine As String)

    Using theProcess As New System.Diagnostics.Process()

        theProcess.StartInfo.FileName = "CMD.EXE "
        theProcess.StartInfo.Arguments = "/Q /C " + strCMDLine

        theProcess.StartInfo.WorkingDirectory = "C:\"

        theProcess.StartInfo.UseShellExecute = False
        theProcess.StartInfo.RedirectStandardOutput = True
        theProcess.StartInfo.RedirectStandardError = True
        theProcess.StartInfo.CreateNoWindow = True
        theProcess.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden

        ' Start the process
        theProcess.Start()

        ' Read stdout and stderr
        ' This implicitly waits for the end of the process. If you want to wait 
        ' explicitly you can use theProcess.WaitForExit()
        Dim stdout As String = theProcess.StandardOutput.ReadToEnd()
        Dim stderr As String = theProcess.StandardError.ReadToEnd()

        ' Read the return code
        Dim iExitCode As Integer = theProcess.ExitCode

        ' Handle the results
        System.Diagnostics.Debug.WriteLine(stdout)

    End Using

End Sub
