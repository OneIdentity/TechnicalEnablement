'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* Sample for connecting an external database, running a SQL statement
'* and handling the results.
'*
'*************************************************************************

' Get values from an external MS SQL database
Public Sub ExpertExternalDatabasesMsSql()

	Dim strConnection As String = "User ID=sa;initial Catalog=<Database>;Data Source=<Server>;Password=<PASSWORT>;Pooling=false;Application Name=<ACCOUNT>"
	Dim strSQL As String = "select UID_Person from person"
	Dim strUID_Person As String

	' Connect the database
	Using sf = DbApp.ConnectTo(strConnection).Using(New ViSqlFactory()).BuildSessionFactory()
		Using dbSession = sf.OpenDbSession()

			' Execute command and get the result set.
			Using dbReader = dbSession.SqlExecute(strSQL)

				' Iterate over the result
				While dbReader.Read()

					' Get string value of first result column
					strUID_Person = dbReader.GetString(0)

					' == Handle the value here ==
				End While
			End Using
		End Using
	End Using
End Sub

' Get values from any database implementing ADO.NET
Public Sub ExpertExternalDatabasesGeneric()
	' This connection string is database system specific, see the documentation of the ADO.NET provider
	Dim strConnection As String = "User ID=sa;initial Catalog=<Database>;Data Source=<Server>;Password=<PASSWORT>;Pooling=false;Application Name=<ACCOUNT>"

	Dim strSQL As String = "select UID_Person from person"
	Dim strUID_Person As String

	' The SqlConnection class is specific for MS SQL, use the connection class for the database system to connect to
	Using dbConnection As New System.Data.SqlClient.SqlConnection(strConnection)

		' Open the connection
		dbConnection.Open()

		' Create a database command object
		Using dbCommand As IDbCommand = dbConnection.CreateCommand()

			' Set the SQL statement to execute
			dbCommand.CommandText = strSQL

			' Execute command and get the result set.
			' Wrap it into a SafeDataReader to use automatic NULL conversion
			Using dbReader = dbCommand.ExecuteReader()

				' Iterate over the result
				While dbReader.Read()
					' Get string value of first result column
					strUID_Person = If(Not dbReader.IsDBNull(0), dbReader.GetString(0), String.Empty)

					' == Handle the value here ==

				End While
			End Using
		End Using
	End Using

End Sub


		'*************************************************************************
		'*
		'* Sample for generic UNS with connecting an external Oracle or
		'* MS SQL database.
		'*
		'*************************************************************************

#If Not SCRIPTDEBUGGER Then
References Oracle.ManagedDataAccess.dll

Imports Oracle.ManagedDataAccess.Client
#End If

' Insert a UNS Account in UNS Group in Oracle
Public Sub Demo_UnsAccountInGroup_Oracle_Add(ByVal dbsUnsAccount As SingleDbObjectSnapshot, ByVal dbsUnsGroup As SingleDbObjectSnapshot)
	Dim f As ISqlFormatter = New VI.DB.Oracle.OracleSqlFormatter()

	Dim strSQL As String = String.Format("Insert into <YourTable> (UserName, RoleName) values ( {0}, {1} )",
f.FormatValue(dbsUnsAccount.GetValue("DistinguishedName").String, ValType.String, True),
f.FormatValue(dbsUnsGroup.GetValue("DistinguishedName").String, ValType.String, True))

	OracleExecute(strSQL)

End Sub

' Delete a UNS Account in UNS Group in Oracle
Public Sub Demo_UnsAccountInGroup_Oracle_Del(ByVal dbsUnsAccount As SingleDbObjectSnapshot, ByVal dbsUnsGroup As SingleDbObjectSnapshot)
	Dim f As ISqlFormatter = New VI.DB.Oracle.OracleSqlFormatter()

	Dim strSQL As String = String.Format("Delete from <YourTable> where {0}",
f.AndRelation(
f.Comparison("UserName", dbsUnsAccount.GetValue("DistinguishedName").String, ValType.String),
f.Comparison("RoleName", dbsUnsGroup.GetValue("DistinguishedName").String, ValType.String))
)

	OracleExecute(strSQL)
End Sub

Public Function GetOracleConnectionString() As String
	Dim cs As New Oracle.ManagedDataAccess.Client.OracleConnectionStringBuilder()

	cs.UserId = "<userId>"
	cs.Password = "<Password>"
	cs.DataSource = "<Server>"

	Return cs.ConnectionString
End Function

Public Sub OracleExecute(ByVal strSQL As String)
	Dim dbFac As IDbFactory = DbApp.GetFactoryByName("VI.DB.Oracle.ViOracleFactory,VI.DB.Oracle")

	Using sf = DbApp.ConnectTo(GetOracleConnectionString()).Using(dbFac).BuildSessionFactory()
		Using dbSession = sf.OpenDbSession()
			dbSession.SqlExecuteNonQuery(strSQL)
		End Using
	End Using
End Sub


' Insert a UNS Account in UNS Group in MsSQL
Public Sub Demo_UnsAccountInGroup_MsSql_Add(ByVal dbsUnsAccount As SingleDbObjectSnapshot, ByVal dbsUnsGroup As SingleDbObjectSnapshot)
	Dim f As ISqlFormatter = New VI.DB.Implementation.MicrosoftSqlFormatter()

	Dim strSQL As String = String.Format("Insert into <YourOracleTable> (UserName, RoleName) values ( {0}, {1} )",
f.FormatValue(dbsUnsAccount.GetValue("DistinguishedName").String, ValType.String, True),
f.FormatValue(dbsUnsGroup.GetValue("DistinguishedName").String, ValType.String, True))

	MsSqlExecute(strSQL)

End Sub

' Delete a UNS Account in UNS Group in MsSQL
Public Sub Demo_UnsAccountInGroup_MsSql_Del(ByVal dbsUnsAccount As SingleDbObjectSnapshot, ByVal dbsUnsGroup As SingleDbObjectSnapshot)
	Dim f As ISqlFormatter = New VI.DB.Implementation.MicrosoftSqlFormatter()

	Dim strSQL As String = String.Format("Delete from <YourMsSqlTable> where {0}",
f.AndRelation(
f.Comparison("UserName", dbsUnsAccount.GetValue("DistinguishedName").String, ValType.String),
f.Comparison("RoleName", dbsUnsGroup.GetValue("DistinguishedName").String, ValType.String))
)

	MsSqlExecute(strSQL)
End Sub

Public Function GetMsSqlConnectionString() As String
	Dim cs As New System.Data.SqlClient.SqlConnectionStringBuilder()
	cs.UserID = "<username>"
	cs.Password = "sys"
	cs.DataSource = "<ServerName>"
	cs.InitialCatalog = "<DatabaseName>"

	Return cs.ConnectionString
End Function

Public Sub MsSqlExecute(ByVal strSQL As String)

	Using sf = DbApp.ConnectTo(GetMsSqlConnectionString()).BuildSessionFactory()
		Using dbSession = sf.OpenDbSession()
			dbSession.SqlExecuteNonQuery(strSQL)
		End Using
	End Using

End Sub
