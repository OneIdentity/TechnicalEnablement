'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* This example shows access to AD from scripts.The sample scripts expect
'* the distinguished name of an AD account.
'*
'* Sample:
'* "LDAP://CN=Jon Doe,OU=Sales,DC=Company,DC=Corp"
'*
'*************************************************************************

' Reference the dll and import the used namespaces
#If Not SCRIPTDEBUGGER Then
References dll
Imports System.DirectoryServices
#End If

Public Sub Expert_ADAccess(ByVal strDN As String)

    Using adEntry As New DirectoryEntry(strDN)

        ' Get property names
        For Each propName As String In adsEntry.Properties.PropertyNames
            VID_Write2Log("C:\Test.Log", propName + ": " + ADSProperty_GetValue(adsEntry, propName))
        Next

        ' Write a property
        adsEntry.Properties("Description").Value = "New description"

        ' Save changes (if permitted)
        adsEntry.CommitChanges()

        ' Remove AD property (not clearing but really removing)
        ADSProperty_Clear(adsEntry, "Description")

    End Using

End Sub

Public Function ADSProperty_GetValue(ByVal adsEntry As DirectoryEntry, ByVal propName As String) As String
    Dim colValues As PropertyValueCollection = adsEntry.Properties(propName)
    Dim strReturn As String = String.Empty

    For Each val As Object In colValues
        strReturn = strReturn + val.ToString()
    Next

    Return strReturn
End Function

Public Sub ADSProperty_Clear(ByVal adsEntry As DirectoryEntry, ByVal propName As String)
    Dim adsUser As Object = adsEntry.NativeObject   ' get native object
    Dim adsType As Type = adsUser.GetType()         ' get native type

    ' Call PutEx
    adsType.InvokeMember("PutEx", Reflection.BindingFlags.InvokeMethod, Nothing, adsUser, New [Object]() {ActiveDs.ADS_PROPERTY_OPERATION_ENUM.ADS_PROPERTY_CLEAR, "Description", Nothing})

    ' Call SetInfo to save values
    adsType.InvokeMember("SetInfo", Reflection.BindingFlags.InvokeMethod, Nothing, adsUser, New [Object]() {})
End Sub
