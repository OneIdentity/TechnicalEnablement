﻿'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* This sample shows the call of commandlet Test-Path. 
'* The commandlet tests the existence of a path. The sample 
'* demonstrates the passing of parameters.
'*
'*************************************************************************

#If Not SCRIPTDEBUGGER Then
        References System.Management.Automation.dll
#End If

Public Function SDK_PowerShell_TestPath(ByVal PathToTest As String) As Boolean

    ' Create and open runspace
    Using rsp As System.Management.Automation.Runspaces.Runspace = System.Management.Automation.Runspaces.RunspaceFactory.CreateRunspace()

        rsp.Open()

        ' Create a pipeline to execute commands
        Using pl As System.Management.Automation.Runspaces.Pipeline = rsp.CreatePipeline()

            ' Create the command object
            Dim cmd As New System.Management.Automation.Runspaces.Command("Test-Path")

            ' Add parameters
            cmd.Parameters.Add("LiteralPath", PathToTest)

            ' Add command to pipeline. This corresponds to the command line
            '   Test-Path -LiteralPath <PathToTest>
            pl.Commands.Add(cmd)

            ' Execute pipeline and retrieve results
            ' Results will provided as collection of PSObject instances
            Dim result As System.Collections.ObjectModel.Collection(Of System.Management.Automation.PSObject) = pl.Invoke()

            ' Evaluate the results
            If pl.Error.Count > 0 Then
                Dim errMsg As String = "Error executing Test-Path"
                For Each msg As Object In pl.Error.ReadToEnd()
                    errMsg += System.Environment.NewLine + msg.ToString()
                Next
                Throw New ViException(errMsg)
            End If

            If result.Count = 1 Then
                If result(0).BaseObject.GetType().Equals(GetType(Boolean)) Then
                    ' Return the result of Test-Path
                    Return CType(result(0).BaseObject, Boolean)
                End If
            End If
        End Using

    End Using

    ' If we reach this the path doesn't exist
    Return False

End Function