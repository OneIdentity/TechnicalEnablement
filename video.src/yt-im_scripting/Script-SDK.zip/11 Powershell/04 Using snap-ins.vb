'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* This sample demonstrates the call of commandlet Export-Mailbox.
'* An Exchange 2007 mailbox will be exported to a *.pst file.
'*
'* To run this snippet the Exchange snap-in
'*    Microsoft.Exchange.Management.PowerShell.Admin
'* has to be loaded.
'*
'* The other requirements of this commandlet can be found there:
'* http://technet.microsoft.com/en-us/library/bb266964%28EXCHG.80%29.aspx
'*
'* Parameters of the script:
'*  SmtpAddress ... SMTP address of the account (i.e. tester@vi.lan)
'*  ExportFile ...  Full name of the *.pst file to create
'*************************************************************************

#If Not SCRIPTDEBUGGER Then
        References System.Management.Automation.dll
#End If

Public Sub SDK_Powershell_ExportMailbox(ByVal SmtpAddress As String, ByVal ExportFile As String)

    ' Create runspace configuration
    Dim rspConfig As System.Management.Automation.Runspaces.RunspaceConfiguration
    rspConfig = System.Management.Automation.Runspaces.RunspaceConfiguration.Create()

    ' Add snap-in to runspace configuration
    Dim snapInException As New System.Management.Automation.Runspaces.PSSnapInException()
    rspConfig.AddPSSnapIn("Microsoft.Exchange.Management.PowerShell.Admin", snapInException)

    ' Check for errors during the snap-in load
    If snapInException.Message.Length > 0 Then
        AppData.Instance.RaiseMessage( _
            MsgSeverity.Warning, _
            String.Format( _
                "Warning when loading Exchange snap-ins: {0}", _
                snapInException.Message _
            ) _
        )
    End If

    ' Create and open runspace
    ' The configuration has to be provided
    Dim rsp As System.Management.Automation.Runspaces.Runspace
    rsp = System.Management.Automation.Runspaces.RunspaceFactory.CreateRunspace(rspConfig)

    Using rsp
        rsp.Open()

        ' Create a pipeline to execute commands
        Using pl As System.Management.Automation.Runspaces.Pipeline = rsp.CreatePipeline()

            ' Create the command object
            Dim cmd As New System.Management.Automation.Runspaces.Command("Export-Mailbox")

            ' Add parameters
            cmd.Parameters.Add("Identity", SmtpAddress)
            cmd.Parameters.Add("PSTFolderPath", ExportFile)
            cmd.Parameters.Add("Confirm", False)

            ' Add command to the pipeline
            pl.Commands.Add(cmd)

            ' Execute pipeline
            pl.Invoke()

            ' Evaluate the results
            If pl.Error.Count > 0 Then
                Dim errMsg As String = "Error during execution of Export-Mailbox: "
                For Each msg As Object In pl.Error.ReadToEnd()
                    errMsg += msg.ToString() + System.Environment.NewLine
                Next
                Throw New ViException(errMsg)
            End If

        End Using
    End Using

End Sub
