'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* ISingleDbObject.GetCR provides a helper object for handling child 
'* relations between tables. Child relations are foreign key relations
'* seen from the other side.
'*
'*************************************************************************
Public Function DBObjects_CR(ByVal uidWorkdesk As String) As String

    Dim dbWorkDesk As ISingleDbObject
    Dim crPerson As IChildRelation
    Dim dbPerson As ISingleDbObject

    ' Load the Workdesk object
    dbWorkDesk = Connection.CreateSingle("Workdesk", uidWorkdesk)

    ' Get the child relation for all Person objects referencing this Workdesk
    crPerson = dbWorkDesk.GetCR("Person", "UID_Workdesk")

    ' Iterate over all Persons attached to this Workdesk
    For Each colElement As IColElem In crPerson.Children
        dbPerson = colElement.Create()
    Next

    ' Iterate over all Persons attached to no Workdesk
    For Each colElement As IColElem In crPerson.ChildrenEmpty
        dbPerson = colElement.Create()
    Next

    ' Iterate over all Persons attached to another Workdesk
    For Each colElement As IColElem In crPerson.ChildrenForeign
        dbPerson = colElement.Create()
    Next

End Function
