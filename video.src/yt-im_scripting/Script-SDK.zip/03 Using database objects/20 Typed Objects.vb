﻿'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'





'*************************************************************************
'*
'* The Database Compiler creates typed wrappers for all objects.
'* This classes can be used to work with object properties in a type
'* safe way.
'*
'*************************************************************************
Public Sub Demo_Typed_Wrappers()

    ' create a typed person object and assign properties
    Dim p As New Person(Session) With {.FirstName = "John", .LastName = "Doe"}

    ' Save the object
    p.Save(Session)

End Sub

Public Sub Demo_Typed_Wrappers_2()

    ' create a typed person object
    Dim p = Session.Source().CreateNew(Of Person)()

    ' assign properties
    p.FirstName = "John"
    p.LastName = "Doe"

    ' Save the object
    p.Save(Session)

End Sub

Public Sub Demo_Typed_Wrappers_Display_And_OldValues()
    ' Topics: 
    ' - Demonstrate the use of Display and DisplayValues with typed wrappers
    ' - Demonstrate the use of OldValues with typed wrappers
    ' - Convert to and from iEntity objects

    ' To get the Display or the LongDisplay of a typed wrapper object 
    ' you can access the wrapped Entity object
    Dim role = Session.Source().Get(Of AERole)("QER-AEROLE-PERSONADMIN-ADMIN")

    ' Access the Display and the LongDisplay of the object using the wrapped Entity
    Debug.Print("{0};{1}", role.Entity.Display, role.Entity.LongDisplay)

    ' Access the DisplayValues of an property the wrapped Entity
    Debug.Print("{0};{1}",
                role.Entity.GetDisplayValue(Session, Table.AERole.ApprovalState),
                role.Entity.GetDisplayValue(Session, "UID_DialogGroup")
                )

    ' Change some properties to demonstrate the access to OldValues
    role.RiskIndex = 1.0

    ' Access the OldValue of a property using the Columns object of the wrapped Entity
    Debug.Print("Old: {0}; New: {1}",
                role.Entity.Columns(Table.AERole.RiskIndex).GetOldValue(Of String),
                role.RiskIndex
                )

    ' Convert a typed wrapper object to an Entity 
    Dim entity As IEntity = role.Entity

    Debug.Print("{0}", entity.LongDisplay)

    ' Convert an Entity to a typed wrapper object
    Dim roleConverted = New AERole()
    roleConverted.Entity = entity

    Debug.Print("{0}", roleConverted.Entity.LongDisplay)

End Sub

Public Sub Demo_Typed_Wrapper_Collection()
    ' Create a Query object
    Dim personQuery = Query _
                    .From(Table.Person) _
                    .Where(Function(t) t.Column(Table.Person.IsInActive) = False) _
                    .SelectNonLobs()

    ' Load the collection of Person objects
    Dim personCollection = Session.Source.GetCollection(Of Person)(personQuery)

    ' Do something for each Person object in the collection
    For Each p In personCollection
        Debug.Print("{0};{1};{2};{3}", p.Entity.Display, p.IsInActive, p.EntryDate.ToLongDateString(), p.Entity.GetDisplayValue(Session, Table.Person.UID_Department))
    Next
End Sub

Public Sub Demo_Typed_Wrapper_Collection_2()
    ' Create a where clause using the SQL Formatter
    Dim f As ISqlFormatter = Session.SqlFormatter
    Dim where As String = f.Comparison(Table.Person.IsInActive, False, ValType.Bool)

    ' Load the collection of Person objects
    Dim personCollection = Session.Source.GetCollection(Of Person)(Query.From(Table.Person).Where(where).SelectNonLobs())

    ' Do something for each Person object in the collection
    For Each p In personCollection
        Debug.Print("{0};{1};{2};{3}", p.Entity.Display, p.IsInActive, p.EntryDate.ToLongDateString(), p.Entity.GetDisplayValue(Session, Table.Person.UID_Department))
    Next
End Sub



Public Sub Demo_Typed_Wrapper_ConfigParms()
    ' The Config class of the typed wrapper allows to acces the configuration parameter hierarchy
    ' 
    ' The value will always from type String and is read-only

    Dim ADSPersonExcludeList As String = Config.TargetSystem.ADS.PersonExcludeList
    Dim GroupAutoPublishADSGroupExcludeList As String = Config.QER.ITShop.GroupAutoPublish.ADSGroupExcludeList

End Sub

Public Sub Demo_Typed_Wrapper_Table_and_Column_names()
    ' The class VI.DB.Model.Table of the typed wrapper allows to acces the table and column names in a typesafe way.
    ' This prevents errors as result of wronlgy typed table or column names in custom code as the compiler checks the correctness.
    ' You can use these for typed wrapper or iEntity objects

    ' Use of tablename (Table.PersonWantsOrg) and column names (Table.PersonWantsOrg.OrderState and Table.PersonWantsOrg.OrderState) in a query object
    Dim pwoQuery = Query _
                    .From(Table.PersonWantsOrg) _
                    .Where(Function(t) t.Column(Table.PersonWantsOrg.OrderState) = 300 And t.Column(Table.PersonWantsOrg.OrderState) = "OrderProduct") _
                    .SelectNonLobs()

    ' Use of the column name (Table.Person.IsInActive) in SQL Formatter
    Dim f As ISqlFormatter = Session.SqlFormatter
    Dim where As String = f.Comparison(Table.Person.IsInActive, True, ValType.Bool)

    ' Using columnnames for getting properties of an iEntity object
    Dim requestCollection = Session.Source.GetCollection(pwoQuery)

    For Each pwo In requestCollection
        ' The With clause is used to shorten the access to the properties by avoiding the prefix Table.PersonWantsOrg
        With Table.PersonWantsOrg
            Debug.Print("{0};{1};{2};{3};{4}",
                    pwo.Display,
                    pwo.GetDisplayValue(Session, .OrderState),
                    pwo.GetValue(.DisplayPersonOrdered).String,
                    pwo.GetValue(.OrderDate).Date,
                    pwo.GetValue(.IsReserved).Bool
                    )
        End With
    Next

    ' Using the tablename during the creation of new iEntity objects
    Dim person As IEntity = Session.Source.CreateNew(Table.Person)

    ' Using columnnames for setting properties of an iEntity object
    With Table.Person
        person.PutValue(.FirstName, "Jon")
        person.PutValue(.LastName, "Doe")
        person.PutValue(.IsExternal, True)
        person.PutValue(.EntryDate, DateTime.Now)
    End With
    person.Save(Session)

End Sub