'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


        '*************************************************************************
'*
'* The interface IEntity supports different options to get or
'* set properties of objects:
'*
'* Get current values:
'*
'*      IEntity.Column(Columnname).GetValue(Object)
'*      IEntity.GetValue(Columnname)    DbVal
'*
'* Get loaded values (after Load OldValue is equal to NewValue)
'*
'*      IEntity.Column(Columnname).GetOldValue(Object)    
'*
'* Set current value
'*
'*      IEntity.PutValue(Column, Value) Object
'*
'*************************************************************************
Public Sub DBObject_ColumnValues()
    Dim dbHardware As IEntity
    Dim strIdent As String
    Dim dtActivate As Date
    Dim bPC As Boolean

    ' Create a new Hardware object
    dbHardware = Session.Source.CreateNew("Hardware")

    '********************************
    '* Set values on column
    dbHardware.Columns("Ident_HardwareList").SetValue("PC-100")
    dbHardware.Columns("Description").SetValue("Description of the hardware")

    '********************************
    ' Set values using PutValue
    dbHardware.PutValue("FileSystem", "FAT")

    '********************************
    '* Get value using NewValue (return type is Object)
    strIdent = CStr(dbHardware.Columns("Ident_HardwareList").GetValue())

    '********************************
    '* Get value using GetValue with type conversion
    strIdent = dbHardware.GetValue("Ident_HardwareList").String
    dtActivate = dbHardware.GetValue("AssetActivate").Date
    bPC = dbHardware.GetValue("IsPC").Bool

    '********************************
    '* Get old/loaded value (return type is Object)
    strIdent = CStr(dbHardware.Columns("Ident_HardwareList").GetOldValue())

End Sub