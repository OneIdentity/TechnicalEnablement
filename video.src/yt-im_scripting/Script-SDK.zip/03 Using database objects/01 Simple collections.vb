'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* Collection objects are used to handle a number of objects in a list.
'*
'*************************************************************************

Public Sub Session_Collection_Simple()

    Dim colPersons As IEntityCollection
    Dim dbPerson As IEntity
    Dim f As ISqlFormatter = Session.SqlFormatter

    ' create the query object
    Dim qPerson = Query.From("Person") _
                  .SelectDisplays()

    ' Load a collection of Person objects
    colPersons = Session.Source.GetCollection(qPerson)

    ' Run through the list
    For Each colElement As IEntity In colPersons

        ' Create a full Person object from the list element.
        ' Attention: This triggers a database SELECT operation 
        ' to get the missing values in most cases. 
        dbPerson = colElement.Create(Session, EntityLoadType.Interactive)

        ' Handle the Person object here
        ' ...
    Next
End Sub


'*************************************************************************
'*
'* The DBCount property delivers the count of objects for the currently
'* active conditions without loading the whole collection.
'* 
'* If you want to handle the elements later, use a combination of Load
'* and Count instead.
'*
'*************************************************************************
  Public Sub Session_Source_GetCount()

    Dim qPerson = Query.From("Person") _
                  .Where(Function(c) c.Column("FirstName") = "Paula").SelectCount()

    ' Get the count of persons with firstname Paula: select count(*) from Person where FirstName = 'Paula'
    Dim iCount = Session.Source.GetCount(qPerson)
End Sub
