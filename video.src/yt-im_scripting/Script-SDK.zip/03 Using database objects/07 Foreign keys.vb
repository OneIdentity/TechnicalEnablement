'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'

'*************************************************************************
'*
'* IEntity.GetFK provides a helper object for handling foreign 
'* key relations between tables. 
'*
'*************************************************************************
Public Function DBObjects_FK(ByVal uidHardware As String) As String
    Dim dbHardware As IEntity
    Dim dbWorkDesk As IEntity
    Dim fkWorkdesk As IEntityForeignKey

    ' Load a hardware object
    dbHardware = Session.Source.Get("Hardware", uidHardware)

    ' Get the foreign key pointing to the Workdesk table
    fkWorkdesk = dbHardware.GetFk(Session, "UID_Workdesk")

    ' If it is not empty
    If Not fkWorkdesk.IsEmpty Then
        ' Create the attached Workdesk object
        dbWorkDesk = fkWorkdesk.GetParent()

        Return dbWorkDesk.Display
    Else
        Return ""
    End If
End Function
