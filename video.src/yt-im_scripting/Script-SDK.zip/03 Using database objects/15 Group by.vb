﻿'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'

'*************************************************************************
'*
'* Even shorter is it to use the LINQ functions from the System.Linq
'* namespace. They support grouping by an attribute using the ToLookup
'* function.
'* 
'*************************************************************************

Public Sub GroupByLinqSample()

    Dim qPerson = Query.From("Person") _
                    .Select("Gender") _
                    .SelectDisplays()

    ' Create a collection of Person objects
    Dim col As IEntityCollection = Session.Source.GetCollection(qPerson, EntityCollectionLoadType.Slim)

    ' Create the grouped structure. the type is inferred automatically.
    ' The first function defines the key of the lookup table.
    ' The second function defines the values sorted under the key.
    Dim grouped = col.ToLookup( _
        Function(e) e.GetValue("Gender").String, _
        Function(e) e)

    ' Iterate over all groups
    For Each grp In grouped

        Debug.WriteLine(grp.Key & ":")

        ' Iterate over all values in the group
        For Each entry As IEntity In grp
            Debug.WriteLine(vbTab & entry.Display)
        Next
    Next
End Sub

