'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* In many cases you need only a limited set of values from a collection.
'* You can retrieve them directly without creating single objects for each
'* entry. They have to be marked as display items to be loaded with the 
'* collection. The advantage is a much higher execution speed.
'* 
'*************************************************************************
  Public Sub Session_Collection_Complex()
    Dim f As ISqlFormatter = Session.SqlFormatter
    Dim colPersons As IEntityCollection
    Dim strPersonnelNumber As String
    Dim strCP09 As String

    Dim qPerson = Query.From("Person") _
                  .Where(f.Comparison("PersonnelNumber", "", ValType.String, CompareOperator.NotEqual)) _
                  .OrderBy("PersonnelNumber") _
                  .Select("PersonnelNumber", "CustomProperty09")

    ' Create a collection of Person entries
    colPersons = Session.Source.GetCollection(qPerson)

    ' Run through the list of Person entries
    For Each colElement As IEntity In colPersons

        ' Get the values directly from the collection element without creating a full object
        strPersonnelNumber = colElement.GetValue("PersonnelNumber").String
        strCP09 = colElement.GetValue("CustomProperty09").String

        ' Use the values for further processing
    Next
End Sub
