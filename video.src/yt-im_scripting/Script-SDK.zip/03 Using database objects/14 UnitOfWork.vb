'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* IUnitOfWork contains a caching mechanism for IEntity instances
'* It caches registered objects and delivers them
'* from the cache instead of reloading them.
'*
'*************************************************************************
Public Sub DBObjects_UnitOfWork()
    Dim colAccounts As IEntityCollection
    Dim f As ISqlFormatter = Connection.SqlFormatter

    ' Create collection of ADSAccount objects
    Dim qAccounts = Query.From("ADSAcccount") _
                    .Where(f.UidComparison("UID_ADSContainer", "", CompareOperator.NotEqual)) _
                          .SelectAll()

    colAccounts = Session.Source.GetCollection(qAccounts, EntityCollectionLoadType.Bulk)

    Using uow = Session.StartUnitOfWork()

        ' Walk through the list of all accounts
        For Each eAccount As IEntity In colAccounts

            ' Assign Department to account
            eAccount.PutValue("Department", "Berlin")

            ' put the object in the unit of work
            uow.Put(eAccount)
        Next

        ' All account objects will be saved here!
        uow.Commit()
    End Using

End Sub