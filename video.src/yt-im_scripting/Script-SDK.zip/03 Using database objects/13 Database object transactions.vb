'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* IEntity objects support an in-memory transaction handling.
'* The current object state including all column values can be saved using 
'* BeginTransaction. CommitTransaction and RollbackTransaction are used to
'* accept the current changes or go back to the old state. Do not confuse 
'* this with database transactions. They are started on the connection.
'*
'* Object transactions are usefull to encapsulate multiple operations on an
'* object in an atomic operation. Either all changes are done or none.
'* 
'* As IEntity supports the ITransactable interface the Transaction
'* helper class can be used for easier handling.
'*
'*************************************************************************
Public Sub DbObject_Transaction(ByVal uidHardware As String, ByVal uidDomain As String, ByVal strSamAccount As String)

    Dim dbHardware As IEntity

    ' Load a Hardware object
    dbHardware = Session.Source.Get("ADSMachine", uidHardware)

    '*********************************************************************
    ' Preferred option: leave exception handling to Using
    '*********************************************************************

    Using t As New Transaction(dbHardware)

        ' Change values, if one of them fails the others are restored 
        ' to their old value too
        dbHardware.PutValue("UID_ADSDomain", uidDomain)
        dbHardware.PutValue("SAMAccountName", strSamAccount)

        ' This call should be the last before End Using. If it is not 
        ' reached the transaction will be rolled back.
        t.Commit()
    End Using

    '*********************************************************************
    ' Other option: Do the exception handling yourselfs
    '*********************************************************************

    ' Start transaction
    dbHardware.BeginTransaction()
    Try

        ' Change values, if one of them fails the others are restored 
        ' to their old value too
        dbHardware.PutValue("UID_ADSDomain", uidDomain)
        dbHardware.PutValue("SAMAccountName", strSamAccount)

        ' Commit the changes. This call should be the last before the Catch block.
        dbHardware.CommitTransaction()
    Catch ex As Exception
        ' An error occured -> roll back the transaction
        dbHardware.RollbackTransaction()

        ' And throw the error to the caller
        Throw
    End Try
End Sub


