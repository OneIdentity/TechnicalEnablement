'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'

'*************************************************************************
'*
'* These samples show potential performance optimizations for
'* collection handling.
'*
'*************************************************************************

'*************************************************************************
'*
'* Without optimizations
'*
'*************************************************************************
Public Sub DEMO_DumpPersons_1()

    Dim dbPerson As IEntity
    Dim dbDepartment As IEntity
    Dim strFile As String = "C:\DEMO\Report1.csv"
    Dim strLOG As String = "C:\DEMO\Report1.log"

    Dim qPerson = Query.From("Person").SelectAll()
    Dim colPerson = Session.Source.GetCollection(qPerson)

    ' Export all persons
    For Each ePerson As IEntity In colPerson

        ' Create the single object
        dbPerson = ePerson.Create(Session)

        ' Write to log file
        VID_Write2Log(strLOG, "Exporting person: " + dbPerson.Display)

        ' Get the department
        dbDepartment = dbPerson.GetFk(Session, "UID_Department").GetParent()

        ' And write the person to the export file
        If Not dbDepartment Is Nothing Then
            VID_Write2Log(strFile, dbPerson.GetValue("Firstname").String + ";" + dbPerson.GetValue("LastName").String + ";" + dbDepartment.GetValue("DepartmentName").String)
        Else
            VID_Write2Log(strFile, dbPerson.GetValue("Firstname").String + ";" + dbPerson.GetValue("LastName").String + ";")
        End If
    Next

End Sub


'*************************************************************************
'*
'*  Optimization: colPerson.PrepareBulkLoad()
'*
'*************************************************************************
Public Sub DEMO_DumpPersons_2()

    Dim dbDepartment As IEntity
    Dim strFile As String = "C:\DEMO\Report2.csv"
    Dim strLOG As String = "C:\DEMO\Report2.log"

    Dim qPerson = Query.From("Person").SelectAll()
    Dim colPerson = Session.Source.GetCollection(qPerson, EntityCollectionLoadType.BulkReadOnly)

    ' Export all persons
    For Each dbPerson As IEntity In colPerson

        ' Write to log file
        VID_Write2Log(strLOG, "Exporting person: " + dbPerson.Display)

        ' Get the department
        dbDepartment = dbPerson.GetFk(Session, "UID_Department").GetParent()

        ' And write the person to the export file
        If Not dbDepartment Is Nothing Then
            VID_Write2Log(strFile, dbPerson.GetValue("Firstname").String + ";" + dbPerson.GetValue("LastName").String + ";" + dbDepartment.GetValue("DepartmentName").String)
        Else
            VID_Write2Log(strFile, dbPerson.GetValue("Firstname").String + ";" + dbPerson.GetValue("LastName").String + ";")
        End If
    Next

End Sub


'*************************************************************************
'*
'* Optimization: Use Dictionary for the foreign keys
'*               Load all export columns using Query 
'*
'*************************************************************************
Public Sub DEMO_DumpPersons_3()

    Dim strFile As String = "C:\DEMO\Report3.csv"
    Dim strLOG As String = "C:\DEMO\Report3.log"
    Dim eDepartment As IEntity

    Dim qPerson = Query.From("Person").Select("FirstName", "LastName", "UID_Department").SelectDisplays()
    Dim colPerson = Session.Source.GetCollection(qPerson, EntityCollectionLoadType.Slim)

    Dim qDepartment = Query.From("Department").Select("DepartmentName")
    Dim colDepartment = Session.Source.GetCollection(qDepartment, EntityCollectionLoadType.Slim)

    ' Convert the loaded departments into a dictionary
    Dim dicDepartment = colDepartment.ToDictionary(Of String)(Function(e) e.GetValue("UID_Department"))

    ' Export all persons
    For Each ePerson As IEntity In colPerson

        ' Write to log file
        VID_Write2Log(strLOG, "Exporting person: " + ePerson.Display)

        ' And write the person to the export file
        If Not String.IsNullOrEmpty(ePerson.GetValue("UID_Department").String) Then

            ' Get the department from the dictionary using the created key
            eDepartment = dicDepartment(ePerson.GetValue("UID_Department").String)

            VID_Write2Log(strFile, ePerson.GetValue("Firstname").String + ";" + ePerson.GetValue("LastName").String + ";" + eDepartment.GetValue("DepartmentName").String)
        Else
            VID_Write2Log(strFile, ePerson.GetValue("Firstname").String + ";" + ePerson.GetValue("LastName").String + ";")
        End If
    Next

End Sub


'*************************************************************************
'*
'* Optimization: Use asynchronous logger
'*               VID_WriteToLog replaced with StreamWriter 
'*
'*************************************************************************
Public Sub DEMO_DumpPersons_4()

    Dim strFile As String = "C:\DEMO\Report3.csv"
    Dim strLOG As String = "C:\DEMO\Report3.log"
    Dim eDepartment As IEntity
    Dim Log As New VI.Base.Logging.Logger()

    Try

        ' Create a asynchronous logger writing to our log file
        Log.AddWriter(New VI.Base.Logging.FileLogWriter(strLog))

        Dim qPerson = Query.From("Person").Select("FirstName", "LastName", "UID_Department")
        Dim colPerson = Session.Source.GetCollection(qPerson, EntityCollectionLoadType.Slim)

        Dim qDepartment = Query.From("Department").Select("DepartmentName", "UID_Department")
        Dim colDepartment = Session.Source.GetCollection(qDepartment, EntityCollectionLoadType.Slim)

        ' Convert the loaded departments into a dictionary
        Dim dicDepartment = colDepartment.ToDictionary(Of String)(Function(e) e.GetValue("UID_Department").String)

        ' The file is opened once and used throughout the whole export
        Using csvFile As System.IO.StreamWriter = System.IO.File.CreateText(strFile)

            ' Export all persons
            For Each ePerson As IEntity In colPerson

                ' Write to log file
                Log.Log("DEMO_DumpPersons_3", ePerson.Display)

                ' And write the person to the export file
                If Not String.IsNullOrEmpty(ePerson.GetValue("UID_Department").String) Then

                    ' Get the department from the dictionary using the created key
                    eDepartment = dicDepartment(ePerson.GetValue("UID_Department").String)

                    csvFile.WriteLine(ePerson.GetValue("Firstname").String + ";" + ePerson.GetValue("LastName").String + ";" + eDepartment.GetValue("DepartmentName").String)
                Else
                    csvFile.WriteLine(ePerson.GetValue("Firstname").String + ";" + ePerson.GetValue("LastName").String + ";")
                End If
            Next

        End Using

    Catch ex As Exception

        Log.Log(New VI.Base.Logging.ExceptionLogMessage("DEMO_DumpPersons_3", ex))

    Finally

        ' Write out all remaining messages and end the logging
        Log.Dispose()

    End Try

End Sub