'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* This sample shows the handling of multi value properties on the basis
'* of the column ADSAccount.OtherMailbox.
'* Multi value properties contain a number of (string) values in one 
'* database field.
'*
'*************************************************************************
Public Function DBObjects_MultiValueProperty(ByVal uidADSAccount As String, ByVal iPos As Integer) As String

    ' Load the ADSAccount object
    Dim dbADSAccount As IEntity = Session.Source.Get("ADSAccount", uidADSAccount)

    ' Create a multi value property object from the data of column OtherMailbox
    Dim mvpOtherMailbox As MultiValueProperty = New MultiValueProperty(dbADSAccount.GetValue("OtherMailbox").String)

    ' Iterate over all values
    For Each mvpValue As String In mvpOtherMailbox
        ' Print out the entry
        System.Diagnostics.Debug.WriteLine(mvpValue)
    Next

    ' Check for existence of an entry
    If Not mvpOtherMailbox.Contains("NewAddress@example.com") Then
        ' Expand the multi value property
        mvpOtherMailbox.Add("NewAddress@example.com")
    End If

    ' Remove a value. If it's not found no exception is thrown.
    mvpOtherMailbox.Remove("NewAddress@example.com")

    ' Set the MVP value into the object column
    dbADSAccount.PutValue("OtherMailbox", mvpOtherMailbox.Value)

    ' Get the entry on the position defined by iPos
    If iPos < mvpOtherMailbox.Count Then
        Return mvpOtherMailbox(iPos)
    Else
        Return String.Empty
    End If

End Function