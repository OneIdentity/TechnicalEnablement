'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* ISingleDbObject.GetMN provides a helper object for handling member 
'* relations between tables. Member relations are handled using a relation 
'* table between the tables on both sides of the relation.
'*
'*************************************************************************
Public Function DBObjects_MN(ByVal uidPerson As String) As String

    Dim dbOrg As ISingleDbObject
    Dim mnPersonInOrg As IMemberRelation
    Dim dbPerson As ISingleDbObject

    ' Load the Person object
    dbPerson = Connection.CreateSingle("Person", uidPerson)

    ' Get the member relation over PersonInOrg to Org
    ' The parameters are the member relation table (PersonInOrg) and the foreign
    ' key column pointing to the table we are coming from (UID_Person)
    mnPersonInOrg = dbPerson.GetMR("PersonInOrg", "UID_Person")

    ' Iterate over all Org objects this Person object is attached to
    For Each colElement As IColElem In mnPersonInOrg.Members
        dbOrg = colElement.Create()

        ' Debug message
        System.Diagnostics.Debug.WriteLine(dbOrg.Display)
    Next

End Function
