'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* Example how to POST an XML text to an REST webservice that is
'* secured by a certificate.
'*
'*************************************************************************


Public Sub DOC_CallRESTService()

    ' REST webservice URL
    Dim url As String = "https://REST.WebService.url"

    Dim serviceRequest As New WebClient()
    Dim sbXML As New StringBuilder()

    ' build the XML string
    sbXML.AppendLine("<DemoXml>")
    sbXML.AppendLine("</DemoXml>")

    Dim req As HttpWebRequest = CType(HttpWebRequest.Create(url), HttpWebRequest)

    Dim postData As String = sbXML.ToString()
    Dim encoding As ASCIIEncoding = New ASCIIEncoding()
    Dim byte1 As Byte() = encoding.GetBytes(postData)

    ' initialize the request class
    req.Method = "POST"
    req.ClientCertificates.Add(System.Security.Cryptography.X509Certificates.X509Certificate.CreateFromCertFile("<Fullpath of certificate file>"))
    req.Accept = "application/xml"
    req.ContentType = "application/xml"
    req.ContentLength = byte1.Length

    ' write the request stream (POST data)
    Dim newStream As Stream = req.GetRequestStream()

        newStream.Write(byte1, 0, byte1.Length)

    newStream.Close()

    ' read response from WEB service
    Dim res As HttpWebResponse = CType(req.GetResponse(), HttpWebResponse)
    Dim rs = New StreamReader(res.GetResponseStream(), encoding)

    Dim strReturn = rs.ReadToEnd()

    ' Process return string here

    rs.Close()
    res.Close()

End Sub