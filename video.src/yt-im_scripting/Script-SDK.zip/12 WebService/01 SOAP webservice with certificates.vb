'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* Example how to add an P12 certificate file to a SOAP webservice call
'* 
'* IMPORTANT: Do not change the name of the method because it 
'*            overloads and extends the base functionality!
'*
'*************************************************************************

#If Not SCRIPTDEBUGGER Then
References System.Web.Services.dll
Imports System.Security.Cryptography
#End If
Public Overrides Function VID_GetWebService(Of T As {New, System.Web.Services.Protocols.SoapHttpClientProtocol})() As T
	Dim cService As T = MyBase.VID_GetWebService(Of T)()

	Dim certFile As String = "C:\<CertificateFile>.P12"
	Dim passWord As String = "<password>"

	cService.ClientCertificates.Add(New System.Security.Cryptography.X509Certificates.X509Certificate2(certFile, passWord))

	Return cService
End Function