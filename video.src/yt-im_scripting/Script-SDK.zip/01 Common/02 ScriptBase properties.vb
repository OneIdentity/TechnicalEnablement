'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* All scripts are member methods or functions of a class. This class 
'* inherits the base class VI.DB.Scripting.ScriptBase. This base class
'* implements some properties and methods that can be used in scripts.
'* These members are shown here.
'*
'*************************************************************************
Public Sub ScriptBase_Variables()

    '  Property: Base 
    '      Type: ISingleDbObject
    '   Meaning: This property contains the current base object for dialog methods, 
    '            dialog object scripts, view insert value scripts and view select scripts.
    '            It is not set in templates, format scripts! In job chains it is only set
    '            if the generation base object was a ISingleDbObject implementation.
    '    Sample:
    Dim strDisplay As String = Base.Display

    '  Property: Connection 
    '      Type: IConnection
    '   Meaning: Get the current database connection
    '    Sample:
    Connection.BeginTransaction()

    '  Property: Provider
    '      Type: IValueProvider
    '   Meaning: Contains the current value provider. This property is not set in the 
    '            script component.
    '            Provider is used for value resolution in the $ notation.
    '    Sample:
    Dim value As String
    value = Provider.GetValue("ColumnName").String
    value = $ColumnName$
    value = $FK(ForeignKeyColumn).ColumnName$

    '  Property: Value
    '      Type: Object
    '   Meaning: Value to manipulate for templates and format scripts. Contains the 
    '            old value when the script is been called and can be manipulated to 
    '            set a new value.
    '    Sample:
    If CStr(Value) = "Value" Then
        Value = "New Value"
    End If

    '  Property: Variables
    '      Type: VarContext
    '   Meaning: Current variables context containing variables defined for the connection
    '    Sample:
    If Not CBool(Variables("FULLSYNC")) Then
        ' Don't do this when the FULLSYNC variable is set
    End If


    '  Property: Entity
    '      Type: IEntity
    '   Meaning: This property contains the current base entity 
    '            Same object like Base
    '    Sample:
    Entity.GetValue("ColumnName").String()

    '  Property: Session
    '      Type: ISession
    '   Meaning: Access to the central database session
    '    Sample:
    Session.Database.Display()

End Sub
