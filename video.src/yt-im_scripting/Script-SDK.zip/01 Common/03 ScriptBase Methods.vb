'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* All scripts are member methods or functions of a class. This class 
'* inherits the base class VI.DB.Scripting.ScriptBase. This base class
'* implements some properties and methods that can be used in scripts.
'* These members are shown here.
'*
'*************************************************************************
Public Sub ScriptBase_Methods()

    '     Method: MsgBox 
    ' Parameters: prompt as String
    '             buttons as System.Windows.Forms.MessageBoxButtons (optional)
    '             title as String (optional)
    '    Returns: System.Windows.Forms.DialogResult
    '    Meaning: Show a message box depending on the frontend technology. 
    '             Using this call message boxes can be shown in the web frontend too.
    '     Sample:
    Dim iReturn As Integer = MsgBox("MessageBox - Text", System.Windows.Forms.MessageBoxButtons.YesNo, "MessageBox - Title")

    If iReturn = System.Windows.Forms.DialogResult.Yes Then
        ' Yes
    Else
        ' No
    End If


    '     Method: RaiseMessage
    ' Parameters: severity as MsgSeverity (optional)
    '             message as String
    '    Meaning: Give a message to the application. This message is written to the 
    '             log when the script runs in a service task.
    '     Sample:
    RaiseMessage("Message in the service log")
    RaiseMessage(MsgSeverity.Warning, "Warning in the service log")


    '     Method: ShowProgress
    ' Parameters: message as String
    '    Meaning: Set the current progress message for scripts running in the script component.
    '     Sample:
    ShowProgress("Progress message of the task")

End Sub

