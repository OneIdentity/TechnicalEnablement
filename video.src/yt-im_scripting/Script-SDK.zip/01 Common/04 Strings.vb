'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* VB.NET contains the class System.String for handling text values.
'* It contains many methods to manipulate strings. Here are shown only
'* some samples.
'*
'* The complete documentation can be found there:
'*   http://msdn.microsoft.com/de-de/library/system.string.aspx
'*
'*************************************************************************
Public Sub Strings()

    ' Define a string variable
    Dim text As String = "Start"

    ' Concatenate text
    text = text + "Suffix"

    ' Text starts/ends with
    If text.StartsWith("Search") Or text.EndsWith("Search") Then

    End If

    ' Get part of a string at the start
    text = text.Substring(0, text.Length - 6)

    ' Convert to upper case
    text = text.ToUpper()

    ' Convert to lower case
    text = text.ToLower()

    ' Case sensitive comparison
    If text = "Start" Then
        Debug.WriteLine("text = ""Start"" finds equality")
    End If

    ' Case insensitive comparison
    If String.Compare(text, "Start", True) = 0 Then
        Debug.WriteLine("String.Compare finds equality")
    End If

    ' Replace occurences in strings
    text = text.Replace("Start", "Begin")

    ' Split text at a defined character. NOTE: The 'c' behind the splitting character defines 
    ' that it is a single character and not a string
    Dim vColumns() As String = CSVLine.Split("e"c)

    ' Complex replacement using regular expressions
    ' The complete documentation can be found there: 
    ' http://msdn.microsoft.com/de-de/library/system.text.regularexpressions.regex.aspx
    text = "Line 1" + Environment.NewLine + "Line 2" + Chr(10) + Chr(13) + "Line 3"
    Dim reg As New System.Text.RegularExpressions.Regex("(\r\n)|(\n\r)|(\r)|(\n)")

    text = reg.Replace(text, Environment.NewLine)

End Sub
