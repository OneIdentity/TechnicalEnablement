'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* This example demonstrates the use of an exception handler in a 
'* script method or function. The exception is been handled completely 
'* and not thrown to the caller.
'*
'*************************************************************************
Public Sub Exceptions_Try_Catch()
    ' Start exception handling block
    Try

        ' The code to observe comes here

    Catch ex As Exception

        ' If an exception occurs this code will be executed 
        VID_Write2Log("C:\Error.log", ViException.ErrorString(ex))

        ' The execution continues after the End Try keyword
    End Try
End Sub


'*************************************************************************
'*
'* This example demonstrates the use of an exception handler in a 
'* script method or function. The exception will be thrown to the caller.
'*
'*************************************************************************
Public Sub Exceptions_Try_Catch2()

	Try
        ' Start a transaction on our connection
        Session.BeginTransaction()

        ' Do something with the database


        ' Commit any changes to the database
        Session.CommitTransaction()
	Catch ex As Exception
        ' An error occured --> rollback any changes 
        Session.RollbackTransaction()

        ' And throw the catched exception to the caller
		Throw
	End Try
End Sub

'*************************************************************************
'*
'* This example demonstrates the use of an exception handler in a 
'* script method or function. A new exception will be thrown to the caller.
'*
'*************************************************************************
Public Sub Exceptions_Try_Catch_Finally()

    Dim sr As System.IO.StreamReader
    Dim line As String

    Try
        ' Open a text file
        sr = New System.IO.StreamReader("TestFile.txt")

        ' read to end
        Do
            line = sr.ReadLine()
        Loop Until line Is Nothing

    Catch e As Exception
        ' Throw a new exception based on the catched one
        Throw New Exception("Error reading TestFile.txt", e)
    Finally
        ' This block will be executed always, even if there was an exception in the Try block
        sr.Close()
    End Try
End Sub

