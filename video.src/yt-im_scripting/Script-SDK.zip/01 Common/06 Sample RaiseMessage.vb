'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


' Called in the SDK process chain Sample_RaiseMessage
' Writes a message into the service log

Public Function Sample_RaiseMessage() As String
			
    AppData.Instance.RaiseMessage(MsgSeverity.Warning, "Sample warning")
    AppData.Instance.RaiseMessage(MsgSeverity.Info, "Sample info")
    AppData.Instance.RaiseMessage(MsgSeverity.Serious, "Sample error message")

    ' language dependent  (DialogMultiLanguage)
			
	AppData.Instance.RaiseMessage (MsgSeverity.Warning, #LD("Sample warning")#)
    AppData.Instance.RaiseMessage (MsgSeverity.Info, #LD("Sample info")#)
    AppData.Instance.RaiseMessage (MsgSeverity.Serious, #LD("Sample error message")#)

End Function