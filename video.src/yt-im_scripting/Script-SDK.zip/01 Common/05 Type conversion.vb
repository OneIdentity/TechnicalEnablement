'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* Samples for the conversion between different data types. 
'*
'* Links for data conversion:
'* - Date     http://msdn.microsoft.com/en-us/library/c6dw49cz(v=VS.90).aspx
'* - Numbers  http://msdn.microsoft.com/en-us/library/2xdwt6xx(v=VS.90).aspx
'*
'*************************************************************************

Public Sub TypeConversion()

    ' Conversion String --> Int
    Value = DbVal.ConvertTo(Of Integer)("145")
    Value = Integer.Parse("145")

    ' Conversion String --> Double
    Value = DbVal.ConvertTo(Of Double)("11222333.990")
    Value = Double.Parse("11222333.990")

    ' Conversion String --> Date
    Value = DateTime.ParseExact("31.12.2005", "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture)

    ' Konvertierung String --> Datum + Zeit nach ISO-Notation
    Value = DbVal.ConvertTo(Of DateTime)("2005-12-31", IsoInvariantCulture.Culture)
    Value = CDate("2005-12-31 15:22:12")

    ' Initialize new date
    Value = New DateTime(2005, 12, 31)

    ' DO NOT USE THIS --> Depending on the locale of the machine this will be parsed as
    ' 12th October 2005 or 10th December 2005
    Value = CDate("12.10.2005")

    ' Conversion String --> Date + Time with exact format specifier
    Value = DateTime.ParseExact("31.12.2005 23:59:01", "dd.MM.yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture)

    ' Conversion current date + time + milliseconds to string in the form 2005-12-13 16:38:15.345
    Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff")

    ' Formatting a decimal number with 3 digits after the decimal point
    ' (NOTE: Decimal point depends on the machine local, i.e. for germany it will be a comma)
    ' en-US: 3.141
    ' de-DE: 3,141
    Value = Math.PI.ToString("0.000")

    ' Comma as thousand separator character, point as decimal separator and three digits after the decimal point
    Value = myDouble.ToString("#,###.000", System.Globalization.CultureInfo.InvariantCulture)

    ' Convert a hexadecimal number to integer
    Value = Integer.Parse("8FAB", Globalization.NumberStyles.HexNumber)

    ' Convert an integer to a hexadecimal number string
    Value = myInteger.ToString("X")
End Sub

