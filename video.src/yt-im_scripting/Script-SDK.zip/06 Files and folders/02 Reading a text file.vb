'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* Sample: Reading a log file line by line
'*
'*************************************************************************

#If Not SCRIPTDEBUGGER Then
Imports System.IO
Imports System.Text
#End If

Public Sub ReadTestFile()

    Dim strLine As String

    ' Create a new stream reader and enclose it in a Using block
    ' to ensure closing the file after reading or in case of exceptions.
    Using srFile As New StreamReader("Test.log", Encoding.UTF8, True)

        ' Second parameter is True --> Try to detect the encoding using the 
        ' byte order marks of the file
        'srFile as New StreamReader("Test.log", True)

        ' Open file using the UNICODE encoding
        'srFile as New StreamReader("Test.log", Encoding.Unicode)

        ' Read the first line
        strLine = srFile.ReadLine()

        ' While end of file is not reached
        While Not strLine Is Nothing

            ' Handle the line
            '...

            ' Read the next line
            strLine = srFile.ReadLine()
        End While

    End Using

End Sub