'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'

#If Not SCRIPTDEBUGGER Then
Imports System.IO
#End If


'*************************************************************************
'*
'* This sample shows some examples for handling files and folders.
'*
'*************************************************************************
Public Sub FileSystemObjects()

    '**********************************************
    '* Check existence of a directory
    Dim bDirExists As Boolean = Directory.Exists("C:\WinNT")

    '**********************************************
    '* Check existence of a file
    Dim bFileExists As Boolean = File.Exists("C:\Boot.ini")

    '**********************************************
    '* Get all files of a directory
    Dim dir As DirectoryInfo = New DirectoryInfo("C:\WinNT")

    Dim vFiles() As FileInfo = dir.GetFiles()

    ' Iterate over the files array
    For Each cFile As FileInfo In vFiles
        ' Handle the file
        System.Diagnostics.Debug.WriteLine(cFile.FullName)
    Next

    '**********************************************
    '* Create a directory
    Directory.CreateDirectory("C:\CreateTest")

    '**********************************************
    '* Remove a directory (Second parameter = True --> recursive)
    Directory.Delete("C:\CreateTest", True)
End Sub


'*************************************************************************
'*
'* This sample checks the folder and it's sub folders for the 
'* existence of any file.
'*
'*************************************************************************
Public Function IsFolderEmty(ByVal path As String) As Boolean
    Dim dir As New DirectoryInfo(Path)

    ' Check for any files in this folder
    Dim dFiles() As String = Directory.GetFiles(path)
    If dFiles.Length() > 0 Then
        Return False
    End If

    ' Check sub directories recursively
    For Each subDir As String In Directory.GetDirectories(path)
        If Not IsFolderEmty(subDir) Then
            Return False
        End If
    Next

    ' The folder is empty
    Return True
End Function

'*************************************************************************
'*
'* Use the static method Path.Combine( path1 as String, path2 as String ) as String
'* to combine a base directory with a sub path or a file name.
'* 
'* This function has several advantages over combining them manually:
'*  - Works on Mono/Linux with the right path separator characters
'*  - Handles trailing backslashes on path1
'*
'* This functionality only combines strings. There are no existence
'* checks in the file system or any other file system interactions.
'*
'*************************************************************************
Public Sub PathCombine()
    Dim test As String

    test = Path.Combine("C:\Test\", "SubDir\Hello")
    ' --> C:\Test\SubDir\Hello

    test = Path.Combine("C:\Test", "Logfile.txt")
    ' --> C:\Test\Logfile.txt

End Sub