'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* Session.Source contains the function Exists to check for the existence of 
'* a data entry in the database. This check is performed without rights 
'* checks to allow data collision detection without administrative rights.
'*
'*************************************************************************
Public Function Session_Exits(ByVal centralAccount As String) As Boolean

    ' Get the SQL formatter for our connection
    Dim f As ISqlFormatter = Session.SqlFormatter

    ' Build the WHERE clause for our check
    Dim where As String = f.Comparison("CentralAccount", centralAccount, ValType.String)

    ' Check if a person with this CentralAccount property already exists
    Return Session.Source.Exists("Person", where)
End Function