'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* Connection variables can be set and read by scripts. Import scripts are
'* one sample for custom connection variables. You can suppress the
'* generation of specific process chains during the import by setting
'* an own connection variable and checking it in the generation condition
'* of the chain.
'*
'* The expression Variables is identical to Session.Variables.
'* It is converted by the script precompiler.
'*
'*************************************************************************
Public Function Session_Variables() As String

    ' Set a connection variable
    Session.Variables.Put("CSVImport", True)

    ' Read a connection variable
    If Not CBool(Session.Variables("CSVImport")) Then
        ' Do something here
    End If

    ' Remove a connection variable
    Session.Variables.Remove("CSVImport")

    ' The connection variable could simply be set to False in this case
    Session.Variables.Item("CSVImport") = False
End Function

