'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* It is possible to immediately create a storage directory on a server
'* when a trouble ticket is created. There may not be sufficient 
'* permissions to create a directory if the frontend runs on a web server.
'* This script changes the user to create the directory with the 
'* permissions of the new user.
'* 
'* To run this script automatically from the TroubleTicket object it's name
'* has to be put into configuration parameter 
'* "SysConfig\TroubleTicket\Attachment\CreatePathScript"
'*
'*************************************************************************

#If Not SCRIPTDEBUGGER Then
    Imports System.Runtime.InteropServices
#End If

Private Declare Auto Function LogonUser Lib "advapi32.dll" (ByVal lpszUsername As [String], _
   ByVal lpszDomain As [String], ByVal lpszPassword As [String], _
   ByVal dwLogonType As Integer, ByVal dwLogonProvider As Integer, _
   ByRef phToken As IntPtr) As Boolean

Private Declare Auto Function CloseHandle Lib "kernel32.dll" (ByVal handle As IntPtr) As Boolean

Private Enum LogonType As Integer
    ''' <summary>
    ''' This logon type is intended for users who will be interactively using the computer, such as a user being logged on  
    ''' by a terminal server, remote shell, or similar process.
    ''' This logon type has the additional expense of caching logon information for disconnected operations;
    ''' therefore, it is inappropriate for some client/server applications,
    ''' such as a mail server.
    ''' </summary>
    LOGON32_LOGON_INTERACTIVE = 2

    ''' <summary>
    ''' This logon type is intended for high performance servers to authenticate plaintext passwords.
    ''' The LogonUser function does not cache credentials for this logon type.
    ''' </summary>
    LOGON32_LOGON_NETWORK = 3

    ''' <summary>
    ''' This logon type is intended for batch servers, where processes may be executing on behalf of a user without
    ''' their direct intervention. This type is also for higher performance servers that process many plaintext
    ''' authentication attempts at a time, such as mail or Web servers.
    ''' The LogonUser function does not cache credentials for this logon type.
    ''' </summary>
    LOGON32_LOGON_BATCH = 4

    ''' <summary>
    ''' Indicates a service-type logon. The account provided must have the service privilege enabled.
    ''' </summary>
    LOGON32_LOGON_SERVICE = 5

    ''' <summary>
    ''' This logon type is for GINA DLLs that log on users who will be interactively using the computer.
    ''' This logon type can generate a unique audit record that shows when the workstation was unlocked.
    ''' </summary>
    LOGON32_LOGON_UNLOCK = 7

    ''' <summary>
    ''' This logon type preserves the name and password in the authentication package, which allows the server to make
    ''' connections to other network servers while impersonating the client. A server can accept plaintext credentials
    ''' from a client, call LogonUser, verify that the user can access the system across the network, and still
    ''' communicate with other servers.
    ''' NOTE: Windows NT:  This value is not supported.
    ''' </summary>
    LOGON32_LOGON_NETWORK_CLEARTEXT = 8

    ''' <summary>
    ''' This logon type allows the caller to clone its current token and specify new credentials for outbound connections.
    ''' The new logon session has the same local identifier but uses different credentials for other network connections.
    ''' NOTE: This logon type is supported only by the LOGON32_PROVIDER_WINNT50 logon provider.
    ''' NOTE: Windows NT:  This value is not supported.
    ''' </summary>
    LOGON32_LOGON_NEW_CREDENTIALS = 9
End Enum

Private Enum LogonProvider As Integer

    ''' <summary>
    ''' Use the standard logon provider for the system.
    ''' The default security provider is negotiate, unless you pass NULL for the domain name and the user name
    ''' is not in UPN format. In this case, the default provider is NTLM.
    ''' NOTE: Windows 2000/NT:   The default security provider is NTLM.
    ''' </summary>
    ''' <remarks></remarks>
    LOGON32_PROVIDER_DEFAULT = 0
End Enum

Public Sub Custom_CreateAttachmentPath(ByVal strFullPath As String)

    Dim tokenHandle As New IntPtr(0)
    Dim dupeTokenHandle As New IntPtr(0)

    Dim identity As System.Security.Principal.WindowsIdentity = Nothing
    Dim impersonatedUser As System.Security.Principal.WindowsImpersonationContext = Nothing

    Dim nc As System.Net.NetworkCredential = Nothing

    tokenHandle = IntPtr.Zero

    Select Case AppData.Instance.AppType
        Case AppType.Web

            Dim credentials As IConfigData = AppData.Instance.Config("applicationpool.credentials", True)

            If Not credentials Is Nothing Then
                If credentials.ValueNames.Length > 0 Then
                    nc = CreateNetworkCredential(credentials.ValueNames(0))
                End If

                ' Get user credentials from the web.config file
                'For Each appInfo As VI.WebBase.AppInfo In VI.WebBase.WebApp.Config.AppPool.Applications
                '        nc = CType(appInfo.Credentials, )
                'Next

            End If

        Case Else
            ' Do nothing
    End Select

    ' If there are no credentials
    If nc Is Nothing Then

        ' Try it without impersonation
        System.IO.Directory.CreateDirectory(strFullPath)

        ' --> done
        Return
    End If

    Try

        ' Logon as other user
        If LogonUser(nc.UserName, nc.Domain, nc.Password, LogonType.LOGON32_LOGON_BATCH, LogonProvider.LOGON32_PROVIDER_DEFAULT, tokenHandle) Then

            Try
                ' Get the WindowsIdentity for this user
                identity = New System.Security.Principal.WindowsIdentity(tokenHandle)

                ' Impersonate this user
                impersonatedUser = identity.Impersonate()

                ' And create the directory
                System.IO.Directory.CreateDirectory(strFullPath)
            Finally

                If Not impersonatedUser Is Nothing Then
                    ' Undo the impersonation
                    impersonatedUser.Undo()

                    impersonatedUser.Dispose()
                End If

                If Not identity Is Nothing Then
                    identity.Dispose()
                End If
            End Try
        Else

            ' Thow any errors
            Dim iError As Integer = Marshal.GetLastWin32Error()

            Throw New System.ComponentModel.Win32Exception(iError)

        End If

    Finally
        If tokenHandle <> IntPtr.Zero Then
            CloseHandle(tokenHandle)
        End If
    End Try
End Sub

Private Function CreateNetworkCredential(ByVal strCredentials As String) As System.Net.NetworkCredential

    Dim rEx As Regex = New Regex(String.Format("(?<Key>\w+)\s*=\s*(?<Value>.*?){0}", ";"), RegexOptions.IgnoreCase)
    Dim h As Hashtable = New Hashtable(3, StringComparer.OrdinalIgnoreCase)

    ' Get all matches. Always put a separator behind to get the last key too
    For Each m As Match In rEx.Matches(strCredentials + ";")
        h(m.Groups("Key").Value) = m.Groups("Value").Value.Trim()
    Next

    If Not h.ContainsKey("User") Or Not h.ContainsKey("Password") Then
        Throw New FormatException("WEB config file part applicationpool.credentials is invalid.")
    End If

    Return New System.Net.NetworkCredential(CStr(h("User")), CStr(h("Password")), CStr(h("Domain")))

End Function