'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'

#If Not SCRIPTDEBUGGER Then
        Imports VI.DB.Passwords
        Imports System.Security
        Imports System.Collections.Generic
#End If
' ---------------------------------------------------------------------------------
' Demonstrate how-to create a random password for an object using password policies
' ---------------------------------------------------------------------------------
Public Function SDK_IPasswordManager_CreatePassword(ObjectKey As String, pwdColumn As String) As String

    If String.IsNullOrEmpty(ObjectKey) Then
        Return String.Empty
    Else
        Dim objKey = New DbObjectKey(ObjectKey)
        Dim entity As IEntity = Nothing

        ' try to load the entity
        If Session.Source.TryGet(objKey, EntityLoadType.Interactive, entity) Then
            ' The base entity has to be provided if the policy is based on a 
            ' specific entity (i.e. IsElementPropertiesDenied, CheckScriptName 
            ' or CreateScriptName are set).

            ' Password will be stored in a SecureString
            Dim password As SecureString = New SecureString

            ' Retrieve an IPasswordManager instance
            Dim passwordManager = Session.Resolve(Of IPasswordManager)()

            ' Retrieve the uid of the policy used for the pwdColumn of the entity 
            ' and include the fallback to the default policy.
            ' 
            ' GetPwdPolicyUidForColumn(myEntity as IEntity, columnName As String, addDefault As Boolean)
            '
            Dim uidPolicy As String = passwordManager.GetPolicyUidForColumn(entity, pwdColumn, True)


            ' Retrieve the policy
            Dim passwordPolicy = passwordManager.GetPolicy(uidPolicy, entity, pwdColumn)

            ' Generate random password 
            password = passwordPolicy.CreatePassword(passwordPolicy.MaxLen)

            Return password.ToInsecure()
        Else
            Return String.Empty
        End If
    End If

End Function

' ------------------------------------------------------------------------------------------
' Demonstrate how-to validate a password against the effective password policiy of an object
' ------------------------------------------------------------------------------------------
Public Function SDK_IPasswordManager_ValidatePassword(ObjectKey As String, pwdColumn As String, unsafepassword As String) As Dictionary(Of Boolean, String)

    ' Retrieve an IPasswordManager instance
    Dim mgr = Session.Resolve(Of IPasswordManager)()

    ' There are functions to verify a user supplied password against a password policy. 
    ' The password has to be a SecureString instance. 
    ' This SecureString can be created using the extension methods from VI.Base.
    Dim password = unsafepassword.ToSecure()

    If Not String.IsNullOrEmpty(ObjectKey) Then

        Dim entity As IEntity = Nothing
        Dim objKey = New DbObjectKey(ObjectKey)

        ' try to load the entity
        If Session.Source.TryGet(objKey, EntityLoadType.Interactive, entity) Then
            ' The base entity has to be provided if the policy is based on a 
            ' specific entity (i.e. IsElementPropertiesDenied, CheckScriptName 
            ' or CreateScriptName are set).

            ' Retrieve an IPasswordManager instance
            Dim passwordManager = Session.Resolve(Of IPasswordManager)()

            ' Retrieve the uid of the policy used for the pwdColumn of the entity 
            ' and include the fallback to the default policy.
            ' 
            ' GetPwdPolicyUidForColumn(myEntity as IEntity, columnName As String, addDefault As Boolean)
            '
            Dim uidPolicy As String = passwordManager.GetPolicyUidForColumn(entity, pwdColumn, True)


            ' Retrieve the policy
            Dim passwordPolicy = passwordManager.GetPolicy(uidPolicy, entity, pwdColumn)

            ' ValidatePassword returns a PasswordValidationResult structure that contains a success flag and error messages
            Dim result As PasswordValidationResult

            result = mgr.ValidatePassword(uidPolicy, entity, pwdColumn, password)

            ' Use the messages from the PasswordValidationResult
            Dim messages As String = String.Empty
            For Each err As ICultureDependentString In result.ValidationErrors
                messages += err.Translated & vbCrLf
            Next

            Return New Dictionary(Of Boolean, String)() From {{result.IsValid, messages}}
        End If
    End If

    ' Return empty dictionary in all other cases
    Return New Dictionary(Of Boolean, String)()

End Function


