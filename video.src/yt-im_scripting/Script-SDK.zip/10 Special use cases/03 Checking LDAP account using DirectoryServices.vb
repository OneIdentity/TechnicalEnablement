﻿'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'**********************************************************************************
'*
'* The script checks the existence of LDAP (or AD) account having given values
'* on special properties
'*
'**********************************************************************************

#If Not SCRIPTDEBUGGER Then
Imports System.DirectoryServices
    References System.DirectoryServices.DLL
#End If

Public Function LDAPObjectExists(ByVal ServerName As String, ByVal Port As String, ByVal RootDN As String, ByVal Login As String, ByVal Password As String, ByVal PropertyName As String, ByVal PropertyValue As String) As Boolean

    ''' <summary>
    ''' the DirectoryServices.DirectorySearcher is used to 
    ''' find any object in directory (LDAP as well as native Microsoft AD) 
    ''' conforming a given search clause (for syntax definition refer to : http://www.ldapexplorer.com/en/manual/109010000-ldap-filter-syntax.htm)
    ''' </summary>

    LDAPObjectExists = False

    ' create the root object of search
    Dim myRoot As New System.DirectoryServices.DirectoryEntry("LDAP://" & ServerName & ":" & Port & "/" & RootDN, Login, Password, System.DirectoryServices.AuthenticationTypes.Serverbind)

    Dim mySearcher As New System.DirectoryServices.DirectorySearcher(myRoot, "(&(objectclass=*) (" & PropertyName & "=" & PropertyValue & "))")

    ' we set a timeout for search to 500 ms
    myTs As New System.TimeSpan(0, 0, 0, 0, 500) 
    mySearcher.ClientTimeout = myTs

    Dim myResult As System.DirectoryServices.SearchResultCollection = mySearcher.FindAll()

    If myResult.Count > 0 Then
        ' there is at least one object in directory 
        LDAPObjectExists = True
    End If

End Function
