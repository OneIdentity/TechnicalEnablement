'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'****************************************************************************************
'* These methods allow a simpler handling of COM objects and provide a better
'* readability of the script code.
'****************************************************************************************
#If Not SCRIPTDEBUGGER Then
Imports System.Reflection
#End If

Private Sub COM_SetProperty(ByVal obj As Object, ByVal sProperty As String, ByVal oValue As Object)
    obj.GetType().InvokeMember(sProperty, BindingFlags.SetProperty, Nothing, obj, New Object() {oValue})
End Sub

Private Function COM_GetProperty(ByVal obj As Object, ByVal sProperty As String, ByVal oValue As Object) As Object
    Return obj.GetType().InvokeMember(sProperty, BindingFlags.GetProperty, Nothing, obj, New Object() {oValue})
End Function

Private Function COM_GetProperty(ByVal obj As Object, ByVal sProperty As String) As Object
    Return obj.GetType().InvokeMember(sProperty, BindingFlags.GetProperty, Nothing, obj, Nothing)
End Function

Private Function COM_GetProperty(ByVal obj As Object, ByVal sProperty As String, ByVal oValue1 As Object, ByVal oValue2 As Object) As Object
    Return obj.GetType().InvokeMember(sProperty, BindingFlags.GetProperty, Nothing, obj, New Object() {oValue1, oValue2})
End Function

Private Function COM_CallMethod(ByVal obj As Object, ByVal sProperty As String, ByVal oParam As Object()) As Object
    Return obj.GetType().InvokeMember(sProperty, BindingFlags.InvokeMethod, Nothing, obj, oParam)
End Function

