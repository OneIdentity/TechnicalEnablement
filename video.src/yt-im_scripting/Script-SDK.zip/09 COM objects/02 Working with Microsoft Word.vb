'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'****************************************************************************************
'* This sample starts Word and loads the document WordTemplate.doc. Then it replaces
'* the fields CallNumber and Customer. At the end the document is saved.
'****************************************************************************************

#If Not SCRIPTDEBUGGER Then
Imports System.Reflection
#End If

Public Sub SDK_RunWord()
    Dim oWord As Object = CreateObject("Word.Application")

    Dim strFile As Object = "C:\MyTemp\WordTemplate.dot"

    COM_SetProperty(oWord, "Visible", True)

    Dim oDocuments As Object = COM_GetProperty(oWord, "Documents")
    Dim oDocument As Object = COM_CallMethod(oDocuments, "Open", New Object() {strFile})
    Dim oFormFields As Object = COM_GetProperty(oDocument, "FormFields")

    For Each oFormField As Object In CType(oFormFields, IEnumerable)
        Select Case CStr(COM_GetProperty(oFormField, "Name")).ToUpper()
            Case "CALLNUMBER"
                COM_SetProperty(oFormField, "Result", "CallNumber")
            Case "CUSTOMER"
                COM_SetProperty(oFormField, "Result", "SDK Customer")
        End Select
    Next

    COM_SetProperty(oFormFields, "Shaded", False)

    COM_CallMethod(oDocument, "Save", Nothing)
End Sub

