'
' ONE IDENTITY LLC. PROPRIETARY INFORMATION
'
' This software is confidential.  One Identity, LLC. or one of its affiliates or
' subsidiaries, has supplied this software to you under terms of a
' license agreement, nondisclosure agreement or both.
'
' You may not copy, disclose, or use this software except in accordance with
' those terms.
'
'
' Copyright 2022 One Identity LLC.
' ALL RIGHTS RESERVED.
'
' ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
' WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
' EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
' FITNESS FOR A PARTICULAR PURPOSE, OR
' NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
' LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
' AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
' THIS SOFTWARE OR ITS DERIVATIVES.
'


'*************************************************************************
'*
'* This section describes generation conditions of process chains
'* and process steps. These conditions are formulated as script 
'* snippets using the "Value = ..." notation.
'*
'*************************************************************************



'*************************************************************************
'* Do not run the chain when doing a full synch of a namespace
'*************************************************************************
Value = not CBool(Variables("FULLSYNC"))


'*************************************************************************
'* Using preprocessor conditions
'*************************************************************************
#If ADS Then
	if $FK(UID_ApplicationServer).FK(UID_Server).IsADSAccount:Bool$ then
		Value =  UCASE($ProfileStateProduction$) = "EMPTY" and not $FK(UID_ApplicationServer).FK(UID_Server).FK(UID_ADSContainer).FK(Ident_Domain).IsInActive:Bool$
	end if
#End If
#If NT4 Then
	if $FK(UID_ApplicationServer).FK(UID_Server).IsNTAccount:Bool$ then
		Value =  UCASE($ProfileStateProduction$) = "EMPTY" and not $FK(UID_ApplicationServer).FK(UID_Server).FK(Ident_DomainServer).IsInActive:Bool$
	end if
#End If

'****************************************************************************
'* Using OUT parameters in process steps
'*
'* OUT parameters can be used to pass a value from one process step of a 
'* process chain to a following step. The OUT parameters are defined in the
'* implementation of the process component and can not be changed.
'*
'* Sample: Component FileComponent task DiskFreeSpace provides an OUT parameter
'* DiskFree. Following jobs can access this value using "&Out(DiskFree)&".
'* This string will be put into the process queue and will be replaced by the
'* service at runtime.
'* 
'* OUT parameters can be overwritten by following jobs.
'* 
'***************************************************************************
Value = CLng("&Out(FileSize)&") < $OnLineLimit:Long$
